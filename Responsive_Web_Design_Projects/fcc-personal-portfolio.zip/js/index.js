 // coded by @ChaituVR
var projectName = 'portfolio';
localStorage.setItem('example_project', 'Personal Portfolio');