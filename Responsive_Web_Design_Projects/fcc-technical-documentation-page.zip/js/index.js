 // coded by @ChaituVR 

var projectName = 'technical-docs-page';
localStorage.setItem('example_project', 'Technical Docs Page');